---
schema: 1
title: "Measured layer refresh lag remains"
kind: "finding"
status: "verified"
date: "2026-10-13"
evidence: ["docs/implementation-progress-2026-10-13.md"]
---

Isolated release layout benchmark: 4000x3000, 174 layers, 60 text layers. Median/p90 milliseconds: idle 1.22/1.44, text visibility 424.76/490.99, opacity 408.07/464.14, pixel-move commit 428.67/447.82, translate operation itself 1.67/2.70.

The benchmark command passed, but latency goals are not met. No comparable before-fix release timing was collected, so the preview mitigation has no claimed speedup. These measure offscreen frames and commands, not physical pen-to-display latency.

Next: profile the expensive work after a layer change before selecting an optimization. Do not assert a specific root cause from the timing gap alone. Native crash investigation remains a separate trust priority. See [execution record](../../reference/implementation-progress-2026-10-13.md).

Per-frame tracing now narrows representative slow frames to the canvas refresh path: about 490-520 ms in gpu-rect refresh versus roughly 2 ms in layer.translate. This includes CPU planning/staging and synchronized GPU work; it does not isolate shader time. The diagnostic run overlapped compilation, so its numbers are not a quiet comparison. Histogram counters are retained background-worker durations. A separate scheduling defect allows obsolete histogram workers to accumulate across edits; its candidate fix and checks are recorded in the execution record.

Second batch completed: bounded histogram scheduling passed the new regression and 2,036 serial UI library tests (ten ignored), strict lint, layers, all 24 wasm checks and desktop build. Live Histogram-visible workflow passed. Paired quiet release opacity medians were 337.92 before / 345.11 after ms; pixel-move commit 323.73 / 326.46 ms. No consistent overall speedup. The remaining lag is inside canvas refresh, which still needs internal stage and cache measurements.
