<!-- Generated reference snapshot; edit the canonical source, then run project_memory.py index. -->
Canonical source: [docs/implementation-progress-2026-10-13.md](../../docs/implementation-progress-2026-10-13.md)

Source content SHA-256: `d104fbbe0a5d1405ec6cc9ccbcfb49ade691907d7f64554d83558c2993bcec38`

# PhotoCraft revamp implementation progress

13 October 2026. This is the current execution record, separate from the immutable original feature audit and planning proposals.

## Current batch

- **F01 / S1: local mitigation implemented and validated.** A fresh pre-change run of the retained GPU test binary reproduced the U16 partial-mip failure. Evidence: `dist/qa/revamp-gpu-before-2026-10-13/`.
- **GPU diagnosis: regression improved; root cause not established.** Added image size, mip path and pixel coordinates to the regression; both direct and scratch paths are attempted even when one fails. An unavailable adapter now fails this required test explicitly instead of silently passing.
- **Obsidian-compatible memory: vault-local snapshots implemented.** Canonical planning/audit sources and this execution record are mirrored into `memory/reference/`; the index links to vault-local readable copies. CSV backlog is rendered as Markdown. Originals remain authoritative and snapshot changes are detected by `check`.
- **F02: still unresolved.** The three original GPU target crashes are not claimed fixed by serial passing.
- **Other F01–F51 product work:** pending; no new shell, AI or beginner workflow is claimed implemented.

Updates below will include validated fixes, the exact checks and remaining limits. Open `memory/INDEX.md` from the memory vault for the same current information in Obsidian. Generated copies are refreshed with `python scripts/project_memory.py index`; do not edit them as an alternative source of truth.


## Diagnosis update

The enriched regression located the direct-path failure at U16 1791x1083, mip 5, pixel (16,16). In that same diagnostic device session the scratch path also failed at U8 mip 5, pixel (16,16); switching to scratch is not a validated workaround. Exact retained diagnostics: dist/qa/revamp-gpu-diagnostic-2026-10-13/.

Candidate change under test: redraw and clear complete mip levels when both dimensions are at most 64 pixels, while retaining bounded partial updates on larger levels. This specifically protects untouched texels in the small reduced previews, with at most a small number of additional texels per edit. It does not blame the driver or claim performance gains. Final results will determine whether it remains.


## Validated rendering change

The bounded small-mip redraw passed the focused GPU checks: eight tests passed, including the expanded readback matrix. It covers 8/16/32-bit inputs, opaque/semi-transparent/transparent backgrounds, center/top-left/bottom-right edits, thin images and both direct/scratch paths. Every reduced level is compared against a full rebuild. Strict UI linting passed.

This is a validated local correctness mitigation, not a confirmed driver root cause or a general GPU stability repair. F02 remains unresolved. Broader UI, WebAssembly, rebuilt live recording and the focused release layout benchmark are still finishing. No claim of faster overall editing or professional beta readiness is made.

Obsidian-compatible vault snapshots now include this execution record, all canonical planning/audit sources and a readable backlog table. `check` detects edited/stale snapshots; `index` refreshes them from canonical sources. Source notes and plans remain reference data, never execution authority.


## Validation infrastructure incident

The initial broad UI test build failed at link time (LNK1180: insufficient disk space), and the desktop, wasm and performance builds also encountered OS error 112. These are retained infrastructure failures, not passing checks or new product assertions. All affected jobs finished.

Recovered about 40 GiB by removing only target/debug/incremental and generated target/debug/deps/*.pdb files after validating their absolute targets. Sources, notes, corpora, recordings and saved outputs were retained. Retried checks use lower native build parallelism; results remain pending until completion. Original failure directories and new retry directories are separate.


## Platform/build progress

The desktop rebuild passed after storage cleanup. It was copied to dist/qa/photocraft-revamp.exe for recording, with a saved SHA-256 fingerprint. All 24 required wasm package/feature checks passed, including photocraft-ui-egui and codecs/HEIF. Dependency-layer validation passed. The UI library passed 2,035 tests with ten ignored; integrations and the release layout benchmark remain in progress.


## Completed batch results

- UI library/integration suite: 2,129 passed, zero failed, ten ignored across 24 test groups, run serially. This does not qualify the old parallel/native crash condition.
- Expanded GPU checks: eight passed on AMD Vulkan; the expanded mip regression passed separately on AMD DX12 (driver 32.0.21037.3009). The matrix includes 54 base cases and 162 center/edge updates, all reduced levels compared with full rebuilds.
- Strict UI lint, targeted formatting, dependency layers, all 24 wasm package/feature checks and the HEIF desktop build passed. Storage-failed initial builds remain separately recorded.
- Valid before/after live recordings: 19.25 and 14.5 seconds, H.264 1920x1200 at four fps. Both check 16-bit import, sampled composite editing/undo/redo and native save; the GPU readback test establishes the preview invariant.
- The first after-recording timed out waiting for screenshots while a benchmark was active. The isolated retry temporarily held the display awake and passed. The timeout cause is not established; no nonexistent/empty video is presented as success.
- Release layout benchmark ran twice after compilation; the final run had no concurrent app recording or GPU test. Its command exited zero, but this is not a latency-budget pass or proof of a speedup.

### Fresh responsiveness evidence

Workload: 4000x3000 (12 MP), 174 layers, 60 text layers, release offscreen GPU frame harness. Final isolated medians / p90: idle 1.22 / 1.44 ms; text visibility 424.76 / 490.99 ms; opacity 408.07 / 464.14 ms; pixel-move commit 428.67 / 447.82 ms; the translate operation itself 1.67 / 2.70 ms. These are frame/operation measurements, not physical pen-to-display latency. No comparable before-fix release benchmark was taken, so no performance improvement is claimed.

The expensive frame after layer changes is now a measured investigation target for F06. Profile rendering/compositing, invalidation and uploads before choosing the next optimization. F02 native-crash investigation, recovery qualification, other adapter/image coverage and the broader UI/novice work remain open.

### Records

[Review the scoped before/after viewer](../../dist/qa/revamp-records-2026-10-13/index.html). Logs, source patch/fingerprints, failed/retry results, synthetic outputs and video health are retained under dist/qa/revamp-*. Original baseline recordings/archive are unchanged. Private control files stay outside shared records and memory. Obsidian snapshots, notes and backlog carry the same current status.


## Second batch: histogram work scheduling

Investigation found that the Histogram panel replaced its pending receiver whenever the document revision changed. Dropping a receiver does not stop its worker: repeated edits could leave multiple CPU thumbnail renders running alongside the GPU canvas. The existing histogram duration is background work, not evidence that the UI blocked for that entire duration.

The candidate change preserves one pending job across edits/document switches, consumes its result with the original revision tag, and requests another frame after completion/disconnection. The latest revision is scheduled next; stale data retains its existing warning. A synthetic test holds a worker pending across three edits, delivers an older result, and checks eventual latest-revision delivery. WebAssembly retains its inline fallback.

An optional PHOTOCRAFT_LAYOUT_TRACE diagnostic in the release layout harness prints slow-frame command, canvas, upload and retained-span counters. Counters explicitly remain last-sample values; they are not all costs incurred in that frame. Profiling and validation are in progress in dist/qa/revamp-layer-profile-2026-10-13 and dist/qa/revamp-histogram-*. No overall latency improvement or closure of F06 is claimed yet.


### Second batch completed checks and limits

The bounded Histogram worker scheduling change passed its corrected five-test tone suite and the entire serial UI library: 2,036 passed, zero failed, ten ignored. Final strict UI clippy, formatting, dependency layers, all 24 wasm package/feature checks, and the HEIF desktop build passed. Python recording checks passed five tests; local-memory checks passed 15 with one host-restricted real-symlink test skipped. Mocked refusal checks still run. No claim of fixing earlier parallel native crashes is made.

The first new Rust regression attempt failed because the minimal egui test pass discarded pending texture deltas. Clearing those test-only deltas corrected the harness; the failed log remains alongside the passing retry. A first Histogram-visible QA attempt used an invalid panels.histogram field; the app correctly rejected it. The retry uses panels.navigator plus dockTabs.navigator = 1 and asserts the tab state. These setup failures are not product regressions. A combined Python unittest invocation had an import-path error; script-entry-point reruns passed, and verified subprocess return codes are saved. PowerShell also reported stderr from passing Python tests as shell errors; direct subprocess results confirm exit zero.

### Paired release responsiveness evidence

Both preserved release executables ran sequentially with nine repetitions on the same PSD-round-tripped 4000x3000 / 174-layer / 60-text-layer workload. GPU synchronization and slow-frame tracing were enabled; Vulkan was requested. No build, UI recording or other GPU test ran during these measurements. This is one before/after sequence on one machine, not a controlled multi-run causal experiment or physical input latency measurement. The initial trace run overlapped compilation and remains diagnostic evidence only.

| Scenario | Before median / p90 (ms) | After median / p90 (ms) |
|---|---:|---:|
| idle frame | 0.79 / 2.27 | 1.19 / 2.00 |
| toggle visibility (text layer) | 351.48 / 399.48 | 335.03 / 349.23 |
| toggle visibility (group) | 37.87 / 423.71 | 29.73 / 340.84 |
| opacity change (Layers / Properties) | 337.92 / 349.78 | 345.11 / 377.98 |
| Move pixel: release (commit) | 323.73 / 342.15 | 326.46 / 362.82 |
| of which layer.translate (pixel) | 1.31 / 2.13 | 1.46 / 2.22 |

The scheduling fix does not deliver a consistent overall speedup. Opacity and pixel-move commit remain hundreds of milliseconds. Representative traces place almost all slow-frame time inside gpu-rect refresh while translate takes around 1-2 ms; that refresh includes CPU planning, staging and synchronized GPU execution. Repeated uploads are visible, but eviction/cache churn or a specific shader cause is not established. Next: measure those internal stages, effect work and cache residency separately. F06 remains open.

### New recordings and saved outputs

Two valid live captures show the rebuilt app: 14.5 seconds for 150-layer nudge/visibility/native save, and 13 seconds with Histogram explicitly visible during the same workflow. Both are H.264, 1920x1200, four fps, checked with ffprobe; screenshots were visually inspected. The Histogram is visible and populated after edits. Video establishes UI workflow behavior; the Rust test establishes pending-worker preservation and eventual latest-revision delivery. These use a 512x384 synthetic sample, not the 12 MP benchmark or original crash fixture. Native 150-layer .pcraft outputs are retained in each capture's samples directory. Temporary display-awake holds were restored successfully.

The [review page](../../dist/qa/revamp-records-2026-10-13/index.html) links these clips, outputs and comparison. Source changes, final source/app hashes, release executables, JSON measurements and all failed/passing logs remain under dist/qa/revamp-histogram-* and revamp-layer-profile-2026-10-13. Private control configuration stays outside the viewer and vault.
